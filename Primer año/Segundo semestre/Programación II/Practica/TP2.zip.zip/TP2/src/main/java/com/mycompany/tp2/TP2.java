/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tp2;

/**
 *
 * @author danie
 */
public class TP2 {

    public static void main(String[] args) {
        System.out.println("Bienvenido al kiosco");
        //Llamo a cada constructor con los datos de los atributos
        Cliente cliente = new Cliente("Juan");
        Vendedor vendedor = new Vendedor("Pablo","Cajero");
        ListaDescuentos listadescuentos = new ListaDescuentos("2x1","con adquirir 2 productos al menos",7);
        ListaPrecios listaprecios = new ListaPrecios("aceite",100);
        MetodoPago metodopago = new MetodoPago("efectivo","10%",12);
        Local local = new Local("San Martin 50",70,5);
        Producto producto = new Producto("aceite",500,250);
        VehiculoTraslado vehiculotraslado = new VehiculoTraslado(5,"blanco",25);
        Heladera heladera = new Heladera(1000,35,"azul");
        Balanza balanza = new Balanza(500,100);
        
        //Pruebo getters y setters
        System.out.println("Cantidad de paginas en la lista de descuentos " + listadescuentos.getCantidadPaginas());
        listadescuentos.setCantidadPaginas(7);
        System.out.println("Páginas modificadas, la nueva cantidad es " + listadescuentos.getCantidadPaginas());
        
        System.out.println("El precio del " + listaprecios.getTipoProducto() + " es de " + listaprecios.getPrecioProductos());
        listaprecios.setPrecioProductos(110);
        System.out.println("El precio del " + listaprecios.getTipoProducto() + " será de " + listaprecios.getPrecioProductos());
        
        //Interaccion
        cliente.buscarProducts("aceite");
        vendedor.ofrecerProducto("aceite");
        listadescuentos.ayudarCliente();
        metodopago.beneficiarCompras();
        producto.enseñarCantidad();
        cliente.pagarProductos(110);
    }
}
