/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tp3completo;

/**
 *
 * @author estudiante
 */
import java.util.Scanner;
public class TP3completo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Selector tareas");
        //Definimos la lista
        ListaTareas lista = new ListaTareas();
        //Bucle para agregar 3 tareas
        for (int i = 0; i < 3; i++){
            lista.agregarTarea();
        }
        lista.mostrarTarea();
        lista.obtenerTarea();
        lista.eliminarTarea(sc.nextInt());
        //lista.eliminarTarea(sc.neXTlINE()); NO SE EJECUTA, debemos pasar un objeto
        lista.estaVacia();
        lista.clonarLista();
    }
}