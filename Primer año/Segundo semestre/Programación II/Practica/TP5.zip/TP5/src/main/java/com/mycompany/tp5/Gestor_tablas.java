package com.mycompany.tp5;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danie
 */
import java.sql.Connection; //clase para manejar conexion con la base
import java.sql.DriverManager;//Importa el administrador de drivers que gestiona la conexión JDBC
import java.sql.SQLException;//clase de errores sql
import java.sql.Statement;//clase para enviar y ejecutar sentencias sql

public class Gestor_tablas {
    
    //conecto con la base de datos local
    public static final String URL = "jdbc:sqlite:agenda.sqlite";
    
    public static void crearTabla(){
        //Asigno la tabla contactos(es mi tabla principal)
        //Siempre primero verifico que la tabla no exista antes de crearla
        String sqlContactos = """
            CREATE TABLE IF NOT EXISTS contactos(
                id INTEGER PRIMARY KEY AUTOINCREMENT, -- Corregido: INTEGER PRIMARY KEY AUTOINCREMENT
                nombre TEXT NOT NULL,                 -- campo de texto para el nombre
                apellido TEXT NOT NULL,               -- campo de texto para el apellido
                telefono TEXT NOT NULL                -- campo de texto para el telefono
            );                                        
        """;
        
        //Asigno a la tabla de emails(sera una tabla secundaria)
        String emails = """
            CREATE TABLE IF NOT EXISTS emails(
                id INTEGER PRIMARY KEY AUTOINCREMENT,                -- Corregido el tipo de dato y primary key
                contacto_id INTEGER NOT NULL,                        -- Corregido el tipo de dato
                email TEXT NOT NULL,                                 -- Campo de texto para el email
                FOREIGN KEY (contacto_id) REFERENCES contactos(id)   -- Clave foránea que relaciona el email con un contacto
            );      
        """;
        
        //Asigno a la tabla direcciones(Sera una tabla secundaria)
        String direcciones = """
            CREATE TABLE IF NOT EXISTS direcciones(
                id INTEGER PRIMARY KEY AUTOINCREMENT,                -- Corregido el tipo de dato y primary key
                contacto_id INTEGER NOT NULL,                        -- Corregido el tipo de dato
                direccion TEXT NOT NULL,                             -- campo de texto para la direccion
                FOREIGN KEY (contacto_id) REFERENCES contactos(id)   -- Clave foránea que relaciona la dirección con un contacto
            );
        """;
        
        //Con un try abre la conexion y el canal de ejecucion, carrandolos al finalizar
        try (Connection conn = DriverManager.getConnection(URL); // Abro la conexión con el archivo
             Statement stmt = conn.createStatement()) {            // Creo el objeto para enviar comandos a la base

            if (conn != null) { // verifico la conexion
                System.out.println("Conectado a la base de datos para crear tablas");

                stmt.execute(sqlContactos);   // creo la tabla Contactos
                stmt.execute(emails);         // creo la tabla emails
                stmt.execute(direcciones);    // creo la tabla direcciones

                System.out.println("¡Tablas creadas con éxito!"); // Mensaje de éxito
            }else{
                System.out.println("No se pudo establecer la conexión");
            }
        } catch (SQLException e) { // Se activa si ocurre algún error durante la ejecución de las consultas SQL
            System.out.println("Error al crear las tablas: " + e.getMessage());
        }
    }
}
