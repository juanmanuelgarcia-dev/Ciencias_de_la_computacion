Algoritmo mayor_n�mero
	definir A,B Como Real
	Escribir "Ingrese el primer n�mero: "
	leer A
	Escribir "Ingrese el segundo n�mero: "
	Leer B
	si A < B Entonces
		Mostrar "El n�mero ",B," es mayor"
	SiNo
		si A > B Entonces
			Mostrar "El n�mero ",A," es mayor"
		SiNo
			Mostrar "Los n�meros ",A," y ",B," son iguales"
		FinSi
	FinSi
FinAlgoritmo
