Algoritmo calculadora
	definir operacion Como Caracter
	definir A,B,resultado Como Real
	Escribir "Ingrese la operaci�n a realizar"
	Leer operaci�n
	Escribir "Ingrese el primer n�mero: "
	leer A
	Escribir "Ingrese el segundo n�mero"
	leer B
	Si operacion = "S" o operacion = "s" Entonces
		resultado <- A + B
		Mostrar "La suma de estos n�meros da ",resultado
	SiNo
		si operacion = "R" o operacion = "r" Entonces
			resultado <- A - B
			Mostrar "La resta de estos da ",resultado
		SiNo
			si operacion = "P" o operacion = "p" o operacion = "M" o operacion = "m" Entonces
				resultado <- A * B
				Mostrar "El producto de ambos n�meros nos da ",resultado
			SiNo
				si operacion = "D" o operacion = "d" Entonces
					resultado = A / B
					Mostrar "La divisi�n de ambos nos da ",resultado
				SiNo
					Mostrar "Ingrese una operaci�n v�lida(s para suma,r para resta,m para producto o d para divisi�n)"
			    FinSi
			FinSi
		finSi
	FinSi
FinAlgoritmo

