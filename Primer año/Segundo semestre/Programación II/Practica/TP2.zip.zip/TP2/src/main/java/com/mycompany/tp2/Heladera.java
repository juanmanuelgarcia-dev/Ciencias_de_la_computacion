/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp2;

/**
 *
 * @author danie
 */
//Clase Heladera
public class Heladera {
    //Atributos
    private int cantidadAlmacenamiento;
    private float electricidadConsumida;
    private String color;

    //Getters y Setters

    public int getCantidadAlmacenamiento() {
        return cantidadAlmacenamiento;
    }

    public void setCantidadAlmacenamiento(int cantidadAlmacenamiento) {
        this.cantidadAlmacenamiento = cantidadAlmacenamiento;
    }

    public float getElectricidadConsumida() {
        return electricidadConsumida;
    }

    public void setElectricidadConsumida(float electricidadConsumida) {
        this.electricidadConsumida = electricidadConsumida;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
   
    
    //Constructores
    public Heladera(int cantidadAlmacenamiento, float electricidadConsumida, String color){
        this.cantidadAlmacenamiento = cantidadAlmacenamiento;
        this.electricidadConsumida = electricidadConsumida;
        this.color = color;
    }

    //Metodos
    public void enseñarProductos(String tipoProducto) {
        System.out.println("En esa heladera que puede almacenar hasta " + this.cantidadAlmacenamiento + " litros, podes ver los productos " + tipoProducto);
    }
    
    public void consumoElectrico(){
        System.out.println("Esta heladera consume " + this.electricidadConsumida + " Watt");
    }
    
    public void refrigerar(){
        System.out.println("Nuestra heladera puede refrigerar hasta " + this.cantidadAlmacenamiento + " Litros, ocupando " + this.electricidadConsumida + " Watts");
    }
}
