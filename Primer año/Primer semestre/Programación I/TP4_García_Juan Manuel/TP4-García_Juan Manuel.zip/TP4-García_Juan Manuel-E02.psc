Algoritmo Base_de_datos
	definir contrase�aIngresada, contrase�aCorrecta, intentos Como Entero
	Escribir "Ingrese su contrase�a para acceder al servidor: "
	leer contrase�aIngresada
	contrase�aCorrecta <- 4321
	intentos <- 0
	si contrase�aIngresada = contrase�aCorrecta Entonces
		Mostrar "Su contrase�a es correcta, puede ingresar"
	SiNo
	repetir
		intentos <- intentos + 1
		Mostrar "La contrase�a es incorrecta"
		Mostrar "Usted lleva ",intentos," intentos"
		Escribir "Ingrese su contrase�a para acceder al servidor: "
		leer contrase�aIngresada
	Mientras Que contrase�aIngresada <> contrase�aCorrecta
	FinSi
FinAlgoritmo