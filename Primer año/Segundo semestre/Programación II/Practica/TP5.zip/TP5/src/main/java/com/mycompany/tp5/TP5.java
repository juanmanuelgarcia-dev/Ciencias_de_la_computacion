/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tp5;

/**
 *
 * @author danie
 */
import java.sql.*;


public class TP5 {
    public static void main(String[] args) {
        Gestor_tablas.crearTabla();
    }
}