/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp4;

/**
 *
 * @author danie
 */
public class EmpleadoNoEncontradoException extends Exception{

    //Constructor que recibe un mensaje
    public EmpleadoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
     
}
