/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp2;
import java.util.Date;
/**
 *
 * @author danie
 */

//Clase cliente
public class Cliente {
    //Atributos
    private String nombre;
    private Date fechaNacimiento;
    private String trabajo;

    //Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTrabajo() {
        return trabajo;
    }

    public void setTrabajo(String trabajo) {
        this.trabajo = trabajo;
    }

    //Constructor para nombre
    public Cliente(String nombre) {
        this.nombre = nombre;
    }
    
    //Métodos
    public void buscarProducts(String nombreProducto) {
        System.out.println("El cliente " + this.nombre + " está buscando el producto " + nombreProducto);
        //System.out.println("El cliente nació en " + fechaNacimiento);
    }
    public void pagarProductos(float precioProductos) {
        System.out.println("El cliente " + this.nombre + " quiero abonar la totalidad de " + precioProductos);
        //System.out.println("El trabajo del cliente es " + trabajo);
    }
    public void revisarPrecios(float precioProductos) {
            System.out.println(" El cliente" + this.nombre + "está revisando el precio del producto " + precioProductos);
    }
}
