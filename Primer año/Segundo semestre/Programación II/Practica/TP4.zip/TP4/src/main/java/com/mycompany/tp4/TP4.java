/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tp4;

/**
 *
 * @author danie
 */
import java.util.Scanner;
public class TP4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CasaNeumaticos casa = new CasaNeumaticos("Casa Neumatios S.A.");
        int opcion;
        System.out.println("Bienvenido a casa Neumáticos");
        System.out.println("Seleccione la opción que desee: ");
        do{
            System.out.println("1. Agregar empleados");
            System.out.println("2. Eliminar empleados");
            System.out.println("3. Agregar clientes");
            System.out.println("4. Eliminar clientes");
            System.out.println("5. Agregar proveedores");
            System.out.println("6. Eliminar proveedores");
            System.out.println("7. Realizar factura");
            opcion = sc.nextInt();
            sc.nextLine(); //limpia el buffer
            switch (opcion){
                case 1:
                    System.out.println("Ingrese el id del empleado");
                    int id = sc.nextInt();
                    System.out.println("Ingrese el teléfono");
                    long tel = sc.nextLong();
                    sc.nextLine();
                    Empleados nuevoEmpleado = new Empleados(id,tel);
                    casa.agregarEmpleado(nuevoEmpleado);
                case 2:
                    System.out.println("Ingrese el id del empleado a eliminar");
                    id = sc.nextInt();
                    sc.nextLine();
                    try {
                        casa.eliminarEmpleado(id);
                    }catch (EmpleadoNoEncontradoException e){
                        System.out.println(e.getMessage());
                    }
                case 3:
                    System.out.println("Ingrese el dni del cliente");
                    int dni = sc.nextInt();
                    Cliente nuevoCliente = new Cliente(dni);
                    casa.agregarClientes(nuevoCliente);
                case 4:
                    System.out.println("Ingrese el dni del cliente a eliminar");
                    dni = sc.nextInt();
                    try {
                        casa.eliminarCliente(dni);
                    }catch (ClienteNoEncontradoException e) {
                        System.out.println(e.getMessage());
                    }
                    
                    
                    
                    
            }
        } while (opcion < 10);
    }
}
