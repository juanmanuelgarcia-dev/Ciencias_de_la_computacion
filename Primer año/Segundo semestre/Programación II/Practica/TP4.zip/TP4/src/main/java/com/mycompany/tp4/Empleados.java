/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp4;

/**
 *
 * @author danie
 */
public class Empleados {
    //Atributos
    private int id;
    private long celular;
    private String nombre;
    
    //Constructor
    public Empleados(int id, long celular,String nombre) {
        this.id = id;
        this.celular = celular;
        this.nombre = nombre;
    }

    //Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getCelular() {
        return celular;
    }

    public void setCelular(long celular) {
        this.celular = celular;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
    public void registrarVenta(Venta venta){
        System.out.println("El empleado " + getId() + " desea registrar la venta de " + venta);
    }
}
