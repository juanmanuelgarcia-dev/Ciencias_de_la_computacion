Algoritmo asterisco
	definir tama�o,i,j Como Entero
	Escribir "Ingrese el tama�o del cuadro: "
	leer tama�o
	Escribir "****"
	para i <- 1 hasta tama�o con paso 1 Hacer
		para j <- 1 Hasta i con paso tama�o Hacer
			Escribir Sin Saltar "*"
		FinPara
		Escribir "  *"
	FinPara
	Escribir "****"
FinAlgoritmo
