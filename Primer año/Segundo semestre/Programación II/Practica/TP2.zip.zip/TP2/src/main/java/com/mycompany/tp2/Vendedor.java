/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp2;

/**
 *
 * @author danie
 */

//Clase vendedor
public class Vendedor {
    //Atributos
    private String nombre;
    private String oficio;
    private int edad;

    //Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getOficio() {
        return oficio;
    }

    public void setOficio(String oficio) {
        this.oficio = oficio;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    //Constructores
    public Vendedor(String nombre, String oficio) {
        this.nombre = nombre;
        this.oficio = oficio;
    }
    
    
    //Métodos
    public void calcularPrecio(int a,int b){
        System.out.println("El precio total fue de " + a + b);
    }
    
    public void ofrecerProducto(String nombreProducto){
        System.out.println("Hola soy " + nombre + " Quiero ofrecerle el producto " + nombreProducto);
    }
    
    public void cobrarProductos(float precioProductos) {
        System.out.println("Debe abonar la cantidad " + precioProductos);
    }
}

