/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp3completo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
//Clase lista tareas
public class ListaTareas {
    private Tarea tarea;
     
    Scanner sc = new Scanner(System.in);
    ArrayList<Tarea> lista = new ArrayList<Tarea>();

    public ListaTareas() {
    }
    
    public void agregarTarea(){
        Tarea tarea = new Tarea();
        //Ingresa el nombre de la tarea
        System.out.println("Ingrese el nombre de la tarea: ");
        tarea.setNombre(sc.nextLine()); //Lo que escribe el usuario lo busca en el set
        System.out.println("Ingrese la descripcion: ");
        tarea.setDescripcion(sc.nextLine());
        lista.add(tarea); //añadimos la tarea a la lista
    }
    
    public void mostrarTarea(){
        int i = 0;
        Iterator<Tarea> listaIt = lista.iterator();
        System.out.println("Listando");
        while(listaIt.hasNext()){
            Tarea tarea = listaIt.next(); //Lee el siguiente elemento de la lista y lo guarda en la variable
            System.out.println("El nombre de la tarea es: " + tarea.getNombre()); //Busca el nombre de la tarea
            System.out.println("La descripcion de la tarea es: " + tarea.getDescripcion()); //Busca la descripcion de la tarea
            System.out.println("Su indice es: " + i);
            i++;
        }
    }
    
    
    //FALTA MANEJO DE EXCEPCIONES
    public void obtenerTarea(){
        int variable;
        System.out.println("Ingrese el indice de la tarea a buscar: ");
        variable = sc.nextInt(); //Pedimos el indice al usuario
        System.out.println("La tarea obtenida es " + lista.get(variable));
    }
    
    public void contenerTarea(){
        System.out.println("Que tarea desea ingresar: ");
        boolean existe = lista.contains(sc.nextLine()); //Pedimos la tarea al usuario
        if (existe = true){
            System.out.println("La tarea existe");
        }else{
            System.out.println("La tarea no existe");
        }
    }
    
    public void indiceTarea(){
        System.out.println("Que tarea desea ingresar: ");
        int posicion = lista.indexOf(sc.nextLine());//Pedimos la tarea al usuario
        System.out.println("El elemento ingresado se encuentra en la posicion " + posicion);
    }
    
    public void eliminarTarea(int indice){
        lista.remove(indice);
        System.out.println("La tarea fue removida con exito");
    }
    
    
    public void eliminarTarea(Tarea tarea){
        lista.remove(tarea);
        System.out.println("La tarea fue removida con exito");
    }
    
    public void limpiarLista(){
        lista.clear();
        System.out.println("La lista fue borrada con exito");
    }
    
    public void estaVacia(){

        if (lista.isEmpty()){ 
            System.out.println("La lista se encuentra vacia");
        }else{
            System.out.println("La lista NO se encuentra vacia");
        }
    }
    
    public ListaTareas clonarLista() {
        ListaTareas copia = new ListaTareas();
        copia.lista = (ArrayList<Tarea>) this.lista.clone();
        return copia;
    }
}
