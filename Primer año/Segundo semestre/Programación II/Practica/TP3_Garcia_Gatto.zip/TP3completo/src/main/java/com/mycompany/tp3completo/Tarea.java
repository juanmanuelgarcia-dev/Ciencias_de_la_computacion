/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp3completo;

/**
 *
 * @author estudiante
 */
public class Tarea {
    //Atributos
    private String nombre;
    private String descripcion;
    private boolean completada;

    public Tarea() {
        this.completada = false;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isCompletada() {
        return completada;
    }
    
    
    //Metodos
    public void mostrarInformacion(){
        System.out.println("El nombre de la tarea es " + this.nombre);
        System.out.println("La informacion es: " + this.descripcion);
        if (completada = false){
            System.out.println("La tarea no ha sido completada");
        
        }else{
            System.out.println("La tarea fue completada");
        }
    }
    
    public void tareaCompletada(){
        System.out.println("La tarea se ha completado con exito");
        this.completada = true;
    }
}
